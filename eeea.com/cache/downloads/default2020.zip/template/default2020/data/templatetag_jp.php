<?php return array (
  1 => 
  array (
    'id' => '1',
    'name' => '首页第一行栏目一',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '92',
      'titlenum' => '20',
      'textnum' => '32',
      'tagtemplate' => 'tag_category_index1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  2 => 
  array (
    'id' => '3',
    'name' => '首页第一行栏目二',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '91',
      'titlenum' => '20',
      'textnum' => '32',
      'tagtemplate' => 'tag_category_index1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  3 => 
  array (
    'id' => '4',
    'name' => '首页第一行栏目三',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '92',
      'titlenum' => '20',
      'textnum' => '32',
      'tagtemplate' => 'tag_category_index1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  4 => 
  array (
    'id' => '5',
    'name' => '首页第一行栏目四',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '91',
      'titlenum' => '20',
      'textnum' => '32',
      'tagtemplate' => 'tag_category_index1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  5 => 
  array (
    'id' => '6',
    'name' => '首页第五行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '88',
      'titlenum' => '20',
      'textnum' => '200',
      'tagtemplate' => 'tag_category_index5.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  6 => 
  array (
    'id' => '7',
    'name' => '首页第六行栏目内容3条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '103',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '60',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_index6.html',
      'submit' => '送信',
    ),
  ),
  7 => 
  array (
    'id' => '8',
    'name' => '首页第七行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '115',
      'titlenum' => '20',
      'textnum' => '60',
      'tagtemplate' => 'tag_category_index7.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  8 => 
  array (
    'id' => '9',
    'name' => '首页第八行栏目内容4条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '108',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '60',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '4',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_index8.html',
      'submit' => '送信',
    ),
  ),
  10 => 
  array (
    'id' => '11',
    'name' => 'About页面第五行右侧栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '121',
      'titlenum' => '8',
      'textnum' => '20',
      'tagtemplate' => 'tag_category_about5r.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  12 => 
  array (
    'id' => '13',
    'name' => '首页第三行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '97',
      'titlenum' => '20',
      'textnum' => '200',
      'tagtemplate' => 'tag_category_index3.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  13 => 
  array (
    'id' => '14',
    'name' => '页底栏目子栏目一',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '103',
      'titlenum' => '6',
      'textnum' => '20',
      'tagtemplate' => 'tag_category_foot-ul.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  15 => 
  array (
    'id' => '16',
    'name' => '页底栏目子栏目二',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '94',
      'titlenum' => '6',
      'textnum' => '20',
      'tagtemplate' => 'tag_category_foot-ul.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  16 => 
  array (
    'id' => '17',
    'name' => '页底栏目子栏目三',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '89',
      'titlenum' => '6',
      'textnum' => '20',
      'tagtemplate' => 'tag_category_foot-ul.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  17 => 
  array (
    'id' => '18',
    'name' => 'About页面第一行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '116',
      'titlenum' => '20',
      'textnum' => '300',
      'tagtemplate' => 'tag_category_about1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  19 => 
  array (
    'id' => '20',
    'name' => 'About页面第二行栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '117',
      'titlenum' => '20',
      'textnum' => '200',
      'tagtemplate' => 'tag_category_about2.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  20 => 
  array (
    'id' => '21',
    'name' => 'About页面第三行栏目滚动内容5条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '118',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '60',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '5',
      'thumb' => 'on',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_about3.html',
      'submit' => '送信',
    ),
  ),
  22 => 
  array (
    'id' => '23',
    'name' => 'About页面第四行栏目内容3条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '119',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '60',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_about4.html',
      'submit' => '送信',
    ),
  ),
  24 => 
  array (
    'id' => '25',
    'name' => 'About页面第五行左侧栏目',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '120',
      'titlenum' => '8',
      'textnum' => '20',
      'tagtemplate' => 'tag_category_about5l.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  25 => 
  array (
    'id' => '26',
    'name' => '首页第九行栏目滚动内容',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '111',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '-1',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '12',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_index9.html',
      'submit' => '送信',
    ),
  ),
  27 => 
  array (
    'id' => '28',
    'name' => '首页第二行子栏目循环',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '94',
      'titlenum' => '20',
      'textnum' => '60',
      'tagtemplate' => 'tag_category_index2.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  28 => 
  array (
    'id' => 29,
    'name' => '商城页面第一行左侧推荐专题大图',
    'tagfrom' => 'special',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'spid' => '1',
      'spimage' => '1',
      'len' => '',
      'tagtemplate' => 'tag_special-index-1.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  29 => 
  array (
    'id' => '30',
    'name' => '商城页面第二行左侧分类',
    'tagfrom' => 'type',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'typeid' => '205',
      'tyimage' => '1',
      'len' => '0',
      'tagtemplate' => 'tag_type-index-1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  30 => 
  array (
    'id' => '31',
    'name' => '商城页面第二行右侧分类',
    'tagfrom' => 'type',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'typeid' => '206',
      'tyimage' => '1',
      'len' => '0',
      'tagtemplate' => 'tag_type-index-1.html',
      'submit' => '送信',
      'attr1' => '0',
    ),
  ),
  31 => 
  array (
    'id' => '32',
    'name' => '商城内容页第四行栏目内容5条',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '122',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '5',
      'thumb' => 'on',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_show_product4.html',
      'submit' => '送信',
    ),
  ),
  32 => 
  array (
    'id' => '33',
    'tagfrom' => 'category',
    'name' => '人力资源页面栏目一',
    'setting' => 
    array (
      'catid' => '112',
      'titlenum' => '20',
      'textnum' => '0',
      'tagtemplate' => 'tag_category_HR.html',
    ),
  ),
  33 => 
  array (
    'id' => 34,
    'name' => '人力资源页面栏目二',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '113',
      'titlenum' => '20',
      'textnum' => '0',
      'tagtemplate' => 'tag_category_HR.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  34 => 
  array (
    'id' => 35,
    'name' => '人力资源页面栏目三',
    'tagfrom' => 'category',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '114',
      'titlenum' => '20',
      'textnum' => '0',
      'tagtemplate' => 'tag_category_HR.html',
      'submit' => '提交',
      'attr1' => '0',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  35 => 
  array (
    'id' => '36',
    'tagfrom' => 'content',
    'name' => '首页第四行栏目滚动内容',
    'setting' => 
    array (
      'catid' => '98',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '60',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '12',
      'thumb' => '1',
      'attr1' => '',
      'tagtemplate' => 'tag_content_index4.html',
    ),
  ),
  36 => 
  array (
    'id' => '37',
    'name' => '热门排行',
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'setting' => 
    array (
      'onlymodify' => '',
      'catid' => '108',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '0',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '10',
      'attr1' => '0',
      'tagtemplate' => 'tag_content_hot.html',
      'submit' => '1',
    ),
  ),
  37 => 
  array (
    'id' => 16,
    'tagfrom' => 'category',
    'name' => 16,
    'setting' => 
    array (
      'remarksname' => 'aaa',
      'catid' => '27',
      'titlenum' => '20',
      'textnum' => '30',
      'tagtemplate' => '',
    ),
  ),
  38 => 
  array (
    'id' => 17,
    'tagfrom' => 'category',
    'name' => 17,
    'setting' => 
    array (
      'remarksname' => 'aa',
      'catid' => '27',
      'titlenum' => '20',
      'textnum' => '30',
      'tagtemplate' => 'tag_category_about5r.html',
    ),
  ),
  39 => 
  array (
    'id' => 18,
    'tagfrom' => 'category',
    'name' => 18,
    'setting' => 
    array (
      'remarksname' => '1111',
      'catid' => '2',
      'titlenum' => '20',
      'textnum' => '30',
      'tagtemplate' => 'tag_category.html',
    ),
  ),
  40 => 
  array (
    'id' => 19,
    'tagfrom' => 'category',
    'name' => 19,
    'setting' => 
    array (
      'remarksname' => '',
      'catid' => '21',
      'titlenum' => '20',
      'textnum' => '30',
      'tagtemplate' => 'tag_category_about5r.html',
    ),
  ),
  41 => 
  array (
    'id' => 20,
    'tagfrom' => 'category',
    'name' => 20,
    'setting' => 
    array (
      'remarksname' => 'aaa',
      'catid' => '21',
      'titlenum' => '20',
      'textnum' => '30',
      'tagtemplate' => 'tag_category_index1.html',
    ),
  ),
  42 => 
  array (
    'id' => 21,
    'tagfrom' => 'category',
    'name' => 21,
    'setting' => 
    array (
      'remarksname' => 'bbbb',
      'catid' => '21',
      'titlenum' => '20',
      'textnum' => '30',
      'tagtemplate' => 'tag_category_index1.html',
    ),
  ),
  43 => 
  array (
    'id' => 22,
    'tagfrom' => 'category',
    'name' => 22,
    'setting' => 
    array (
      'remarksname' => '栏目标签',
      'catid' => '24',
      'titlenum' => '11',
      'textnum' => '32',
      'tagtemplate' => 'tag_category_index_title.html',
    ),
  ),
  44 => 
  array (
    'id' => 23,
    'tagfrom' => 'special',
    'name' => 23,
    'setting' => 
    array (
      'remarksname' => 'aaaaaaaa',
      'spid' => '1',
      'spname' => '1',
      'subtitle' => '1',
      'spimage' => '1',
      'spcontent' => '1',
      'len' => '-1',
      'tagtemplate' => 'tag_special-index-1.html',
    ),
  ),
  45 => 
  array (
    'id' => 24,
    'tagfrom' => 'type',
    'name' => 24,
    'setting' => 
    array (
      'remarksname' => 'aaabbb',
      'typeid' => '1',
      'tyname' => '1',
      'subtitle' => '1',
      'tyimage' => '1',
      'typecontent' => '1',
      'len' => '-1',
      'tagtemplate' => 'tag_type-index-1.html',
    ),
  ),
  46 => 
  array (
    'id' => 25,
    'tagfrom' => 'special',
    'name' => 25,
    'setting' => 
    array (
      'remarksname' => '测试专题',
      'spid' => '1',
      'spname' => '1',
      'subtitle' => '1',
      'spimage' => '1',
      'spcontent' => '1',
      'len' => '100',
      'tagtemplate' => 'tag_special-index-1.html',
    ),
  ),
  47 => 
  array (
    'id' => 26,
    'tagfrom' => 'category',
    'name' => 26,
    'setting' => 
    array (
      'remarksname' => '栏目标题',
      'catid' => '11',
      'titlenum' => '20',
      'textnum' => '0',
      'tagtemplate' => 'tag_category_index_title.html',
    ),
  ),
  48 => 
  array (
    'id' => 27,
    'tagfrom' => 'content',
    'tagcontent' => '',
    'name' => 27,
    'setting' => 
    array (
      'remarksname' => '内容列表',
      'catid' => '11',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '-1',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'onlymodify' => '',
      'thumb' => 'off',
      'attr1' => '',
      'tagtemplate' => 'tag_content_index4.html',
    ),
  ),
  49 => 
  array (
    'id' => 38,
    'tagfrom' => 'content',
    'tagcontent' => 'null',
    'name' => 38,
    'setting' => 
    array (
      'onlymodify' => '',
      'submit' => '1',
      'remarksname' => 'About页面第三行栏目滚动内容5条',
      'catid' => '21',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '1',
      'introduce_length' => '2',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'thumb' => 'off',
      'attr1' => '0',
      'tagtemplate' => 'tag_content.html',
      'catname' => '',
      'htmldir' => '',
      'introduce' => '',
    ),
  ),
  50 => 
  array (
    'id' => 39,
    'tagfrom' => 'content',
    'tagcontent' => '',
    'name' => 39,
    'setting' => 
    array (
      'remarksname' => '测试内容',
      'catid' => '24',
      'son' => '1',
      'typeid' => '0',
      'spid' => '0',
      'length' => '20',
      'introduce_length' => '-1',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '3',
      'onlymodify' => '',
      'thumb' => 'off',
      'attr1' => '',
      'tagtemplate' => 'tag_content.html',
    ),
  ),
  51 => 
  array (
    'id' => 40,
    'tagfrom' => 'content',
    'tagcontent' => '',
    'name' => 40,
    'setting' => 
    array (
      'remarksname' => 'aa',
      'catid' => '11',
      'son' => '1',
      'typeid' => '0',
      'spid' => '1',
      'length' => '20',
      'introduce_length' => '-1',
      'ordertype' => 'adddate-desc',
      'istop' => '0',
      'limit' => '10',
      'onlymodify' => '',
      'thumb' => 'off',
      'attr1' => '',
      'tagtemplate' => 'tag_content.html',
    ),
  ),
);