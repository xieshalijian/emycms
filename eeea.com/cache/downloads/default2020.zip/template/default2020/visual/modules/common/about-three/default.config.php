<?php return array (
    'modulesname' => 'about-three',      //组件名称
    'version' => '1.0',                //版本
);