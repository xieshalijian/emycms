<!-- 组件开始 -->
<div class="lyrow position-move container-fluid-box ">
    <!--层按钮-->
    {setting_butoon_layouts}
    <div class="preview">
        <img src="{$template_path}/visual/modules/common/about-two/about-two.jpg" alt="{lang_sections('column_pic_info')}">
        <p>{lang_sections('column_pic_info')}</p>
    </div>
    <div class="view">
        <div class="container-fluid about-two clearfix">
            <div class="row about-two-row column">
                <div class="col-md-6 col-xs-12 pull-right">
                    <div class="row column">
                        <div class="element-box">
                            <!--栏目组件按钮-->
                            {setting_butoon_category}
                            <div class="view">
                                <div class="tag">
                                    <span class="removeClean tagname">&#123;tag_modules_category_common_about-two_1&#125;</span>
                                    {tag_modules_category_common_about-two_1}
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-xs-12 pull-left">
                    <div class="row column">
                        <div class="element-box">
                            <!--栏目组件按钮-->
                            {setting_butoon_category}
                            <div class="view">
                                <div class="tag">
                                    <span class="removeClean tagname">&#123;tag_modules_category_common_about-two_2&#125;</span>
                                    {tag_modules_category_common_about-two_2}
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
</div>
<!-- 组件结束 -->