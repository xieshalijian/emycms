
    <link href="{$template_path}/visual/modules/common/about-one/css/style.css" rel="stylesheet">

    <div class="about-one-right-img about-one-right-img-2">
        <a title="董事长致辞" href="/index.php?case=archive&amp;act=list&amp;catid=31">
            <img alt="董事长致辞" cmseasy-id="31" class="cmseasyeditimg lazy" src="{$base_url}/cn/upload/images/201908/15590892414438.jpg">
        </a>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
    <style type="text/css">
        .about-one-right-img-2 {
            background:rgba(255, 255, 255, 0);
            border-color:rgba(255, 255, 255, 0);
        }
        .about-one-right-img-2:hover {
            background:rgba(255, 255, 255, 0);
            border-color:rgba(255, 255, 255, 0);
        }
    </style>
