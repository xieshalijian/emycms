
    <link href="{$template_path}/visual/modules/common/about-columns/css/style-2.css" rel="stylesheet">


    <div class="about-columns-img about-columns-img-2">
        <a title="关于我们" href="/index.php?case=archive&amp;act=list&amp;catid=1" target="_blank">
            <img alt="关于我们" src="{$base_url}/cn/upload/images/201908/guanyu.jpg" class="cmseasyeditimg" cmseasy-id="1">
        </a>
    </div>



    <style type="text/css">
        .about-columns-img-2 img {
            height: 250px;
        }
        .about-columns-img:before{
            background: #ffffff;
        }

    </style>
