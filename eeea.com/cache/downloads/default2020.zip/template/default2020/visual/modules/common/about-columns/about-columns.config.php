<?php return array (
  1 => 
  array (
    'id' => '1',
    'tagfrom' => 'category',
    'default' => true,
    'catid' => '21',
    'titlenum' => '20',
    'textnum' => '0',
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '250px',
        'type' => 'text',
      ),
      'title-size' => 
      array (
        'value' => '22px',
        'type' => 'text',
      ),
      'title-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'title-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'subtitle-size' => 
      array (
        'value' => '16px',
        'type' => 'text',
      ),
      'subtitle-color' => 
      array (
        'value' => '#666666',
        'type' => 'color',
      ),
      'subtitle-hover-color' => 
      array (
        'value' => '#666666',
        'type' => 'color',
      ),
      'p-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'p-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'p-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
    ),
    'title' => '栏目设置',
    'defaultDemo' => '1.default',
    'cn' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '1',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '栏目设置',
      'defaultDemo' => '1.default',
    ),
    'en' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '51',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'Column setting',
      'defaultDemo' => '1.default',
    ),
    'jp' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '88',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'セクションの設定',
      'defaultDemo' => '1.default',
    ),
    'sk' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '123',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '프로그램 설정',
      'defaultDemo' => '1.default',
    ),
    'user' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '82',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '栏目设置',
      'defaultDemo' => '1.default',
    ),
  ),
  2 => 
  array (
    'id' => '2',
    'tagfrom' => 'category',
    'default' => true,
    'catid' => '21',
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '250px',
        'type' => 'text',
      ),
      'background-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'background-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'background-border-color' => 
      array (
        'value' => 'rgba(255, 255, 255, 0)',
        'type' => 'color',
      ),
      'background-border-hover-color' => 
      array (
        'value' => 'rgba(255, 255, 255, 0)',
        'type' => 'color',
      ),
    ),
    'title' => '栏目图片设置',
    'defaultDemo' => '2.default',
    'cn' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '1',
      'title' => '栏目图片设置',
      'defaultDemo' => '2.default',
    ),
    'en' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '51',
      'title' => 'Column picture setting',
      'defaultDemo' => '2.default',
    ),
    'jp' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '88',
      'title' => 'コラム画像の設定',
      'defaultDemo' => '2.default',
    ),
    'sk' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '123',
      'title' => '코너 이미지 설정',
      'defaultDemo' => '2.default',
    ),
    'user' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '51',
      'title' => '栏目图片设置',
      'defaultDemo' => '2.default',
    ),
  ),
  3 => 
  array (
    'sk' => 
    array (
      'id' => 3,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '123',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '프로그램 설정',
      'defaultDemo' => '1.default',
    ),
    'jp' => 
    array (
      'id' => 3,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '88',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'セクションの設定',
      'defaultDemo' => '1.default',
    ),
    'en' => 
    array (
      'id' => 3,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '51',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'Column setting',
      'defaultDemo' => '1.default',
    ),
    'cn' => 
    array (
      'id' => '3',
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '1',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '栏目设置',
      'defaultDemo' => '1.default',
    ),
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '250px',
        'type' => 'text',
      ),
      'title-size' => 
      array (
        'value' => '22px',
        'type' => 'text',
      ),
      'title-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'title-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'subtitle-size' => 
      array (
        'value' => '16px',
        'type' => 'text',
      ),
      'subtitle-color' => 
      array (
        'value' => '#666666',
        'type' => 'color',
      ),
      'subtitle-hover-color' => 
      array (
        'value' => '#666666',
        'type' => 'color',
      ),
      'p-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'p-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'p-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
    ),
  ),
  4 => 
  array (
    'sk' => 
    array (
      'id' => 4,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '123',
      'title' => '코너 이미지 설정',
      'defaultDemo' => '2.default',
    ),
    'jp' => 
    array (
      'id' => 4,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '88',
      'title' => 'コラム画像の設定',
      'defaultDemo' => '2.default',
    ),
    'en' => 
    array (
      'id' => 4,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '51',
      'title' => 'Column picture setting',
      'defaultDemo' => '2.default',
    ),
    'cn' => 
    array (
      'id' => '4',
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '1',
      'title' => '栏目图片设置',
      'defaultDemo' => '2.default',
    ),
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '250px',
        'type' => 'text',
      ),
      'background-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'background-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'background-border-color' => 
      array (
        'value' => 'rgba(255, 255, 255, 0)',
        'type' => 'color',
      ),
      'background-border-hover-color' => 
      array (
        'value' => 'rgba(255, 255, 255, 0)',
        'type' => 'color',
      ),
    ),
  ),
);