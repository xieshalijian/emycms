<?php return array (
  1 => 
  array (
    'id' => '1',
    'tagfrom' => 'category',
    'default' => true,
    'catid' => '21',
    'titlenum' => '20',
    'textnum' => '200',
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '350px',
        'type' => 'text',
      ),
      'title-size' => 
      array (
        'value' => '22px',
        'type' => 'text',
      ),
      'title-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'title-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'subtitle-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'subtitle-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'subtitle-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'p-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'btn-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'btn-border-radius' => 
      array (
        'value' => '50px',
        'type' => 'text',
      ),
      'btn-border-hover-radius' => 
      array (
        'value' => '50px',
        'type' => 'text',
      ),
      'btn-text-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'btn-text-hover-color' => 
      array (
        'value' => '#333333',
        'type' => 'color',
      ),
      'btn-border-color' => 
      array (
        'value' => '#c8a063',
        'type' => 'color',
      ),
      'btn-border-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'btn-background-color' => 
      array (
        'value' => '#c8a063',
        'type' => 'color',
      ),
      'btn-background-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'background-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
      'background-hover-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
    ),
    'title' => '栏目设置',
    'defaultDemo' => '1.default',
    'cn' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '32',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '栏目设置',
      'defaultDemo' => '1.default',
    ),
    'en' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '82',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'Column setting',
      'defaultDemo' => '1.default',
    ),
    'jp' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '117',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'セクションの設定',
      'defaultDemo' => '1.default',
    ),
    'sk' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '152',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '프로그램 설정',
      'defaultDemo' => '1.default',
    ),
    'user' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '82',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '栏目设置',
      'defaultDemo' => '1.default',
    ),
  ),
  2 => 
  array (
    'id' => '2',
    'tagfrom' => 'category',
    'default' => true,
    'catid' => '21',
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '350px',
        'type' => 'text',
      ),
    ),
    'title' => '栏目图片',
    'defaultDemo' => '2.default',
    'cn' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '32',
      'title' => '栏目图片',
      'defaultDemo' => '2.default',
    ),
    'en' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '82',
      'title' => 'Column picture',
      'defaultDemo' => '2.default',
    ),
    'jp' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '117',
      'title' => 'コラム画像',
      'defaultDemo' => '2.default',
    ),
    'sk' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '152',
      'title' => '코너 이미지',
      'defaultDemo' => '2.default',
    ),
    'user' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '82',
      'title' => '栏目设置',
      'defaultDemo' => '2.default',
    ),
  ),
  3 => 
  array (
    'sk' => 
    array (
      'id' => 3,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '152',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '프로그램 설정',
      'defaultDemo' => '1.default',
    ),
    'jp' => 
    array (
      'id' => 3,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '117',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'セクションの設定',
      'defaultDemo' => '1.default',
    ),
    'en' => 
    array (
      'id' => 3,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '82',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => 'Column setting',
      'defaultDemo' => '1.default',
    ),
    'cn' => 
    array (
      'id' => '3',
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '32',
      'titlenum' => '20',
      'textnum' => '200',
      'title' => '栏目设置',
      'defaultDemo' => '1.default',
    ),
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '350px',
        'type' => 'text',
      ),
      'title-size' => 
      array (
        'value' => '22px',
        'type' => 'text',
      ),
      'title-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'title-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'subtitle-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'subtitle-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'subtitle-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'p-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'btn-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'btn-border-radius' => 
      array (
        'value' => '50px',
        'type' => 'text',
      ),
      'btn-border-hover-radius' => 
      array (
        'value' => '50px',
        'type' => 'text',
      ),
      'btn-text-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'btn-text-hover-color' => 
      array (
        'value' => '#333333',
        'type' => 'color',
      ),
      'btn-border-color' => 
      array (
        'value' => '#c8a063',
        'type' => 'color',
      ),
      'btn-border-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'btn-background-color' => 
      array (
        'value' => '#c8a063',
        'type' => 'color',
      ),
      'btn-background-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'background-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
      'background-hover-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
    ),
  ),
  4 => 
  array (
    'sk' => 
    array (
      'id' => 4,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '152',
      'title' => '코너 이미지',
      'defaultDemo' => '2.default',
    ),
    'jp' => 
    array (
      'id' => 4,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '117',
      'title' => 'コラム画像',
      'defaultDemo' => '2.default',
    ),
    'en' => 
    array (
      'id' => 4,
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '82',
      'title' => 'Column picture',
      'defaultDemo' => '2.default',
    ),
    'cn' => 
    array (
      'id' => '4',
      'tagfrom' => 'category',
      'default' => false,
      'catid' => '32',
      'title' => '栏目图片',
      'defaultDemo' => '2.default',
    ),
    'custom' => 
    array (
      'height' => 
      array (
        'value' => '350px',
        'type' => 'text',
      ),
    ),
  ),
);