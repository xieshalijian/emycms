
    <link href="{$template_path}/visual/modules/common/about-three/css/style-2.css" rel="stylesheet">
    <div class="col-md-12">
        <div class="about-three-right">
            <div class="swiper-container about-slide-nav about-slide-nav-6 swiper-container-initialized swiper-container-horizontal swiper-container-free-mode swiper-container-thumbs">
                <div class="swiper-wrapper" style="transition-duration: 0ms;">
                    <div class="swiper-slide swiper-slide-thumb-active swiper-slide-visible swiper-slide-active" style="width: 220px; margin-right: 10px;">
                        <div cmseasy-id="36" cmseasy-table="archive" cmseasy-field="title" class="cmseasyedit about-slide-nav-tiem">
                            <font style="color:;">1982</font>                </div>
                    </div>
                    <div class="swiper-slide swiper-slide-visible swiper-slide-next" style="width: 220px; margin-right: 10px;">
                        <div cmseasy-id="35" cmseasy-table="archive" cmseasy-field="title" class="cmseasyedit about-slide-nav-tiem">
                            <font style="color:;">1983</font>                </div>
                    </div>
                    <div class="swiper-slide swiper-slide-visible" style="width: 220px; margin-right: 10px;">
                        <div cmseasy-id="34" cmseasy-table="archive" cmseasy-field="title" class="cmseasyedit about-slide-nav-tiem">
                            <font style="color:;">1987</font>                </div>
                    </div>
                    <div class="swiper-slide swiper-slide-visible" style="width: 220px; margin-right: 10px;">
                        <div cmseasy-id="33" cmseasy-table="archive" cmseasy-field="title" class="cmseasyedit about-slide-nav-tiem">
                            <font style="color:;">1995</font>                </div>
                    </div>
                    <div class="swiper-slide swiper-slide-visible" style="width: 220px; margin-right: 10px;">
                        <div cmseasy-id="32" cmseasy-table="archive" cmseasy-field="title" class="cmseasyedit about-slide-nav-tiem">
                            <font style="color:;">2000</font>                </div>
                    </div>
                </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span><span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
            <div class="swiper-container about-slide-content swiper-container-initialized swiper-container-horizontal">
                <div class="swiper-wrapper" style="transition-duration: 0ms; transform: translate3d(-1150px, 0px, 0px);"><div class="swiper-slide swiper-slide-duplicate swiper-slide-prev" data-swiper-slide-index="4" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="2000" href="/index.php?case=archive&amp;act=show&amp;aid=32">
                                    <img cmseasy-id="32" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="32" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1982年公司成立。                            </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="0" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="1982" href="/index.php?case=archive&amp;act=show&amp;aid=36">
                                    <img cmseasy-id="36" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy swiper-lazy-loaded" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="36" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1982年公司成立。                            </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="1" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="1983" href="/index.php?case=archive&amp;act=show&amp;aid=35">
                                    <img cmseasy-id="35" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="35" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1983年公司发生的事。                            </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" data-swiper-slide-index="2" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="1987" href="/index.php?case=archive&amp;act=show&amp;aid=34">
                                    <img cmseasy-id="34" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="34" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1987年公司发生的事。                            </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide" data-swiper-slide-index="3" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="1995" href="/index.php?case=archive&amp;act=show&amp;aid=33">
                                    <img cmseasy-id="33" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="33" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1995年公司发生的事。                            </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide swiper-slide-duplicate-prev" data-swiper-slide-index="4" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="2000" href="/index.php?case=archive&amp;act=show&amp;aid=32">
                                    <img cmseasy-id="32" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="32" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1982年公司成立。                            </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="0" style="width: 1140px; margin-right: 10px;">
                        <div class="about-slide-content-item">
                            <div class="about-three-right-img">
                                <a title="1982" href="/index.php?case=archive&amp;act=show&amp;aid=36">
                                    <img cmseasy-id="36" cmseasy-table="archive" cmseasy-field="content" class="cmseasyeditimg swiper-lazy swiper-lazy-loaded" src="{$base_url}/cn/upload/images/201908/15590908078262.jpg">
                                </a>
                            </div>
                            <div class="about-three-right-text about-three-right-text-6">
                                <div class="about-three-right-text2 about-three-right-text2-6">
                                    <p cmseasy-id="36" cmseasy-table="archive" cmseasy-field="intro" class="cmseasyedit textarea">
                                        1982年公司成立。                            </p>
                                </div>
                            </div>
                        </div>
                    </div></div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
        </div>
    </div>
    <script src="{$template_path}/visual/modules/common/about-three/js/about-three.js" type="text/javascript"></script>
    <style type="text/css">
        .about-three-right-text-6 .about-three-right-text2 p {
            font-size:$_p-size;
            color:$_p-color;
        }
        .about-three-right-text-6 .about-three-right-text2 p:hover {
            color:$_p-hover-color;
        }
        .about-three-right-text2-6:before{background: url({$template_path}/visual/modules/common/about-three/images/1.png) center center no-repeat;}
        .about-three-right-text2-6:after{background: url({$template_path}/visual/modules/common/about-three/images/2.png) center center no-repeat;}
    </style>