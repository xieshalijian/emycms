<?php return array (
  1 => 
  array (
    'id' => '1',
    'tagfrom' => 'category',
    'default' => true,
    'catid' => '$catid',
    'titlenum' => '20',
    'custom' => 
    array (
      'title-size' => 
      array (
        'value' => '22px',
        'type' => 'text',
      ),
      'title-color' => 
      array (
        'value' => '#000000',
        'type' => 'color',
      ),
      'title-hover-color' => 
      array (
        'value' => '#000000',
        'type' => 'color',
      ),
      'subtitle-size' => 
      array (
        'value' => '16px',
        'type' => 'text',
      ),
      'subtitle-color' => 
      array (
        'value' => '#999999',
        'type' => 'color',
      ),
      'subtitle-hover-color' => 
      array (
        'value' => '#999999',
        'type' => 'color',
      ),
    ),
    'title' => '栏目标题',
    'defaultDemo' => '1.default',
    'cn' => 
    array (
      'id' => '1',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '$catid',
      'titlenum' => '20',
     
      'title' => '栏目标题',
      'defaultDemo' => '1.default',
    ),
      'en' =>
          array (
              'id' => '1',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '$catid',
              'titlenum' => '20',
             
              'title' => 'Set up',
              'defaultDemo' => '1.default',
          ),
      'jp' =>
          array (
              'id' => '1',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '$catid',
              'titlenum' => '20',
             
              'title' => 'セクションの設定',
              'defaultDemo' => '1.default',
          ),
      'sk' =>
          array (
              'id' => '1',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '$catid',
              'titlenum' => '20',
             
              'title' => '프로그램 설정',
              'defaultDemo' => '1.default',
          ),
      'user' =>
          array (
              'id' => '1',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '82',
              'titlenum' => '20',
              'textnum' => '200',
              'title' => '栏目设置',
              'defaultDemo' => '1.default',
          ),
  ),
  2 => 
  array (
    'id' => '2',
    'tagfrom' => 'category',
    'default' => true,
    'catid' => '$catid',
    'titlenum' => '20',
    'textnum' => '100',
    'custom' => 
    array (
      'link-font-size' => 
      array (
        'value' => '14px',
        'type' => 'text',
      ),
      'link-color' => 
      array (
        'value' => '#000000',
        'type' => 'color',
      ),
      'link-hover-color' => 
      array (
        'value' => '#ffffff',
        'type' => 'color',
      ),
      'link-border-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
      'link-border-hover-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
      'link-border-radius' => 
      array (
        'value' => '0px',
        'type' => 'text',
      ),
      'link-background-color' => 
      array (
        'value' => 'rgba(255, 255, 255, 0)',
        'type' => 'color',
      ),
      'link-background-hover-color' => 
      array (
        'value' => '#06276a',
        'type' => 'color',
      ),
    ),
    'title' => '子栏目标题',
    'defaultDemo' => '1.default',
    'cn' => 
    array (
      'id' => '2',
      'tagfrom' => 'category',
      'default' => true,
      'catid' => '$catid',
      'titlenum' => '20',

      'title' => '子栏目标题',
      'defaultDemo' => '1.default',
    ),
      'en' =>
          array (
              'id' => '2',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '$catid',
              'titlenum' => '20',

              'title' => 'Sub column title',
              'defaultDemo' => '1.default',
          ),
      'jp' =>
          array (
              'id' => '2',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '$catid',
              'titlenum' => '20',

              'title' => '小欄の見出し',
              'defaultDemo' => '1.default',
          ),
      'sk' =>
          array (
              'id' => '2',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '$catid',
              'titlenum' => '20',

              'title' => '하위 프로그램 제목',
              'defaultDemo' => '1.default',
          ),
      'user' =>
          array (
              'id' => '2',
              'tagfrom' => 'category',
              'default' => true,
              'catid' => '82',
              'titlenum' => '20',

              'title' => '栏目设置',
              'defaultDemo' => '1.default',
          ),
  ),
);