<link href="{$template_path}/visual/modules/category/category-title/css/style-2.css" rel="stylesheet">

