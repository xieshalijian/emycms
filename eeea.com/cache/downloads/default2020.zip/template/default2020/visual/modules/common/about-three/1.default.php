
    <link href="{$template_path}/visual/modules/common/about-three/css/style-1.css" rel="stylesheet">
    <div class="col-md-12">
        <div class="list-title list-title-5">
            <h4>
                <a title="发展历程" href="/index.php?case=archive&amp;act=list&amp;catid=33" cmseasy-id="33" cmseasy-table="category" cmseasy-field="catname" class="cmseasyedit">
                    发展历程            </a>
            </h4>
        </div>
    </div>
    <style type="text/css">
        .list-title-5 h4 a {
            font-size:22px;
            color:$_link-color;
        }
        .list-title-5 h4 a:hover {
            color:$_link-hover-color;
        }
        .list-title-5 p {
            font-size:14px;
            color:$_p-color;
        }
        .list-title-5 p:hover {
            color:$_p-hover-color;
        }
    </style>