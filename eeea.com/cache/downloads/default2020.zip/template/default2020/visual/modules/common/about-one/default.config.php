<?php return array (
    'modulesname' => 'about-one',      //组件名称
    'version' => '1.0',                //版本
);