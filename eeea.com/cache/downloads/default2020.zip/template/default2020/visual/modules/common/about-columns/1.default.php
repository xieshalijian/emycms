
    <link href="{$template_path}/visual/modules/common/about-columns/css/style-1.css" rel="stylesheet">


    <div class="about-columns-text about-columns-text-3">
        <h4>
            <a title="关于我们" href="/index.php?case=archive&amp;act=list&amp;catid=1" cmseasy-id="1" class="cmseasyedit">
                关于我们                </a>
        </h4>

        <p cmseasy-id="1" class="cmseasyedit content">
            企业一般是指以盈利为目的，运用各种生产要素（土地、劳动力、资本、技术和企业家才能等），向市场提供商品或服务，实行自主经营、自负盈亏、独立核算的法人或其他社会经济组织。在商品经济范畴内，作为组织单元的多种模式之一，按照一定的组织规律，有机构成的经济实体，一般以营利为目的，以实现投资人、客户、员工、社会大众的利益最大化为使命，通过提供产品或服务换取收入。它是社会发展的产物，因社会分工的发展而成长壮大。            </p>

        <em></em>
    </div>



    <style type="text/css">
        .shopping-pics-thumbs .shopping-pics-small-item {

        }
        .about-columns-text-3 h4 a {
            font-size:22px;
            color:#ffffff;
        }
        .about-columns-text-3 h4 a:hover {
            color:#ffffff;
        }
        .about-columns-text-3 .subtitle {
            font-size:16px;
            color:#666666;
        }
        .about-columns-text-3 .subtitle:hover {
            color:#666666;
        }
        .about-columns-text-3 p {
            font-size:14px;
            color:#ffffff;
        }
        .about-columns-text-3 p:hover {
            color:#ffffff;
        }
        .about-columns .container {
            background:$_background-color;
        }
    </style>
