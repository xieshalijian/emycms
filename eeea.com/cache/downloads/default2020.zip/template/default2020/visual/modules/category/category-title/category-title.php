<!-- 组件开始 -->
<div class="lyrow position-move element-box clearfix">
    <!--层按钮-->
    {setting_butoon_layouts}
    <div class="preview">
        <img src="{$template_path}/visual/modules/category/category-title/category-title.jpg">
        <p>
            {lang_sections('column_title')}
        </p>
    </div>
    <div class="view">
        <div class="category-title">
            <div class="column">
                <div class="element-box">
                    {setting_butoon_category}
                    <div class="view">
                        <div class="tag">
                        <span class="removeClean tagname">
                            &#123;tag_modules_category_category_category-title_1&#125;
                        </span>
                            {tag_modules_category_category_category-title_1}
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="element-box">
                    {setting_butoon_category}
                    <div class="view">
                        <div class="tag">
                        <span class="removeClean tagname">
                            &#123;tag_modules_category_category_category-title_2&#125;
                        </span>
                            {tag_modules_category_category_category-title_2}
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- 组件结束 -->
