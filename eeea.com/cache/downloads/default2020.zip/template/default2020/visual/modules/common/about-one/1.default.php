
    <link href="{$template_path}/visual/modules/common/about-one/css/style.css" rel="stylesheet">


    <div class="about-one-title about-one-title-1">
        <div class="row">
            <div class="col-md-12">
                <p cmseasy-id="31" class="cmseasyedit">
                    CHAIRMANS SPEECH                </p>
                <h4>
                    <a title="董事长致辞" href="/index.php?case=archive&amp;act=list&amp;catid=31" cmseasy-id="31" class="cmseasyedit">
                        董事长致辞                    </a>
                </h4>

            </div>
        </div>
    </div>
    <div class="about-one-right-text about-one-right-text-1 cmseasyedit content" cmseasy-id="31">
        <p>
            我们构建创新解决方案以解决当今的环境挑战，从而拉动经济增长。“健康创想”承诺让更多人更健康。我们通过富有想象力的理念和成熟的解决方案，创造更健康的世界。        </p>
    </div>
    <div class="clearfix"></div>

    <style type="text/css">
        .about-one-1 {
            background:rgba(255, 255, 255, 0);
        }
        .about-one-1:hover {
            background:rgba(255, 255, 255, 0);
        }
        .about-one-title-1 h4 a {
            font-size:22px;
            color:#000000;
        }
        .about-one-title-1 h4 a:hover {
            color:#000000;
        }
        .about-one-title-1 p {
            font-size:16px;
            color:#000000;
        }
        .about-one-title-1 p:hover {
            color:#000000;
        }
        .about-one-right-text-1 {
            font-size:14px;
            color:#000000;
            background:rgba(255, 255, 255, 0);
            border-color:rgba(255, 255, 255, 0);
        }

        .about-one-right-text-1:hover {
            color:#000000;
            background:rgba(255, 255, 255, 0);
            border-color:rgba(255, 255, 255, 0);
        }
    </style>
