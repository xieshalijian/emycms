<link href="{$template_path}/visual/modules/category/category-title/css/style-1.css" rel="stylesheet">

<p>
    About US        </p>
<div class="clearfix"></div>
<h1>
    关于我们        </h1>

<style type="text/css">

    .category-title h1 {
        font-size:22px;
        color:#000000;
    }
    .category-title h1:hover {
        color:#000000;
    }
    .category-title p {
        font-size:16px;
        color:#999999;
    }
    .category-title p:hover {
        color:#999999;
    }
</style>