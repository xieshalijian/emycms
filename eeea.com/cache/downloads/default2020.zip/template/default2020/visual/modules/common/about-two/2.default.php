
    <link href="{$template_path}/visual/modules/common/about-two/css/style-2.css" rel="stylesheet">

    <div class="about-two-left-img about-two-left-img-4">
        <img alt="集团简介" cmseasy-id="32" class="cmseasyeditimg lazy img-auto" src="{$base_url}/cn/upload/images/201908/15590892812276.jpg">
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
    <style type="text/css">
        .about-two-left-img-4 {
            height: 350px;
            background:$_background-color;

        }
        .about-two-left-img-4:hover {
            background:$_background-hover-color;
        }
    </style>

