<?php return array (
  'custom' => 
  array (
    'title-size' => 
    array (
      'value' => '20px',
      'type' => 'text',
    ),
    'title-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'title-hover-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
      'p-size' =>
          array (
              'value' => '14px',
              'type' => 'text',
          ),
      'p-color' =>
          array (
              'value' => '#333333',
              'type' => 'color',
          ),
      'p-hover-color' =>
          array (
              'value' => '#333333',
              'type' => 'color',
          ),
      'link-font-size' =>
          array (
              'value' => '14px',
              'type' => 'text',
          ),
      'link-color' =>
          array (
              'value' => '#ffffff',
              'type' => 'color',
          ),
      'link-hover-color' =>
          array (
              'value' => '#ffffff',
              'type' => 'color',
          ),
      'link-border-color' =>
          array (
              'value' => 'rgba(255, 255, 255, 0)',
              'type' => 'color',
          ),
      'link-border-hover-color' =>
          array (
              'value' => 'rgba(255, 255, 255, 0)',
              'type' => 'color',
          ),
      'link-border-radius' =>
          array (
              'value' => '2px',
              'type' => 'text',
          ),
      'link-border-hover-radius' =>
          array (
              'value' => '2px',
              'type' => 'text',
          ),
      'link-background-color' =>
          array (
              'value' => '#06276a',
              'type' => 'color',
          ),
      'link-background-hover-color' =>
          array (
              'value' => '#06276a',
              'type' => 'color',
          ),
  ),
);