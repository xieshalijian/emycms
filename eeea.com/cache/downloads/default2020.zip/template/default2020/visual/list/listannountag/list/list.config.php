<?php return array (
  'custom' => 
  array (
    'align-number' => 
    array (
      'value' => '5',
      'type' => 'select',
      'select' => '1/1,2/2,3/3,4/4,5/5',
    ),
    'title-number' => 
    array (
      'value' => '20',
      'type' => 'text',
    ),
    'isdate' => 
    array (
      'value' => '1',
      'type' => 'select',
      'select' => '1/是,0/否',
    ),
    'link-font-size' => 
    array (
      'value' => '16px',
      'type' => 'text',
    ),
    'link-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'link-hover-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'link-border-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-border-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-border-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-border-hover-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-background-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
      'align-data' =>
          array (
              'value' => 'pull-right',
              'type' => 'select',
              'select' => 'pull-right/右,pull-left/左',
          ),
    'btn-size' => 
    array (
      'value' => '12px',
      'type' => 'text',
    ),
    'btn-border-radius' => 
    array (
      'value' => '15px',
      'type' => 'text',
    ),
    'btn-border-hover-radius' => 
    array (
      'value' => '15px',
      'type' => 'text',
    ),
    'btn-text-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'btn-text-hover-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'btn-border-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-border-hover-color' => 
    array (
      'value' => '#777777',
      'type' => 'color',
    ),
    'btn-background-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-background-hover-color' => 
    array (
      'value' => '#777777',
      'type' => 'color',
    ),
  ),

'title' => 'setting-title',
);