<?php return array (
  'custom' => 
  array (
    'align-number' => 
    array (
      'value' => '4',
      'type' => 'select',
      'select' => '12/1,6/2,4/3,3/4,2/6',
    ),
    'title-size' => 
    array (
      'value' => '16px',
      'type' => 'text',
    ),
    'title-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'title-hover-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'p-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'p-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'p-hover-color' => 
    array (
      'value' => '#666666',
      'type' => 'color',
    ),
    'intro-number' => 
    array (
      'value' => '30',
      'type' => 'text',
    ),
    'btn-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'btn-border-radius' => 
    array (
      'value' => '30px',
      'type' => 'text',
    ),
    'btn-border-hover-radius' => 
    array (
      'value' => '30px',
      'type' => 'text',
    ),
    'btn-text-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-text-hover-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'btn-border-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-border-hover-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'btn-background-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'background-hover-color' => 
    array (
      'value' => '#f5f5f5',
      'type' => 'color',
    ),
    'background-border-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'background-border-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
  ),
);