<?php return array (
  'custom' => 
  array (
    'align-number' => 
    array (
      'value' => '3',
      'type' => 'select',
      'select' => '12/1,6/2,3/4,4/3',
    ),
    'link-font-size' => 
    array (
      'value' => '16px',
      'type' => 'text',
    ),
    'link-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'link-hover-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'link-border-style' => 
    array (
      'value' => 'dotted',
      'type' => 'select',
      'select' => 'none/无,dotted/点,solid/实线,double/双线',
    ),
    'link-border-hover-style' => 
    array (
      'value' => 'dotted',
      'type' => 'select',
      'select' => 'none/无,dotted/点,solid/实线,double/双线',
    ),
    'link-border-color' => 
    array (
      'value' => '#cccccc',
      'type' => 'color',
    ),
    'link-border-hover-color' => 
    array (
      'value' => '#cccccc',
      'type' => 'color',
    ),
    'link-border-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-border-hover-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-background-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
  ),
);