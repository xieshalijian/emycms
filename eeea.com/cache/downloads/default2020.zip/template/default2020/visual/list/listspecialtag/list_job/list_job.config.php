<?php return array (
  'custom' => 
  array (
    'title-size' => 
    array (
      'value' => '16px',
      'type' => 'text',
    ),
    'title-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'title-hover-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'link-font-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'link-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'link-hover-color' => 
    array (
      'value' => '#000000',
      'type' => 'color',
    ),
    'link-border-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-border-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-border-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-border-hover-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-background-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'btn-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'btn-border-radius' => 
    array (
      'value' => '5px',
      'type' => 'text',
    ),
    'btn-border-hover-radius' => 
    array (
      'value' => '5px',
      'type' => 'text',
    ),
    'btn-text-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'btn-text-hover-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'btn-border-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'btn-border-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'btn-background-color' => 
    array (
      'value' => '#f6f7f7',
      'type' => 'color',
    ),
    'btn-background-hover-color' => 
    array (
      'value' => '#666666',
      'type' => 'color',
    ),
    'background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'background-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'background-border-color' => 
    array (
      'value' => '#eeeeee',
      'type' => 'color',
    ),
    'background-border-hover-color' => 
    array (
      'value' => '#eeeeee',
      'type' => 'color',
    ),
  ),

'title' => 'setting-title',
);