<?php return array (
  'custom' => 
  array (
    'title-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'title-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'title-hover-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'subtitle-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'subtitle-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'subtitle-hover-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'p-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'p-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'p-hover-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'background-color' => 
    array (
      'value' => '#f5f5f5',
      'type' => 'color',
    ),
    'background-hover-color' => 
    array (
      'value' => '#cccccc',
      'type' => 'color',
    ),
    'background-border-color' => 
    array (
      'value' => '#eeeeee',
      'type' => 'color',
    ),
    'background-border-hover-color' => 
    array (
      'value' => '#cccccc',
      'type' => 'color',
    ),
    'btn-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'btn-border-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'btn-border-hover-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'btn-text-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'btn-text-hover-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'btn-border-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-border-hover-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-background-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'btn-background-hover-color' => 
    array (
      'value' => '#06276a',
      'type' => 'color',
    ),
  ),
);