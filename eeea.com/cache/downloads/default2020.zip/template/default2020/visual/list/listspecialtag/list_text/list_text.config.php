<?php return array (
  'custom' => 
  array (
    'align-number' => 
    array (
      'value' => '12',
      'type' => 'select',
      'select' => '12/1,6/2,3/4',
    ),
    'link-font-size' => 
    array (
      'value' => '16px',
      'type' => 'text',
    ),
    'link-color' => 
    array (
      'value' => '#333333',
      'type' => 'color',
    ),
    'link-hover-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'link-border-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-border-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-border-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-border-hover-radius' => 
    array (
      'value' => '0px',
      'type' => 'text',
    ),
    'link-background-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'link-background-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'p-size' => 
    array (
      'value' => '14px',
      'type' => 'text',
    ),
    'p-color' => 
    array (
      'value' => '#999999',
      'type' => 'color',
    ),
    'p-hover-color' => 
    array (
      'value' => '#ffffff',
      'type' => 'color',
    ),
    'intro-number' => 
    array (
      'value' => '140',
      'type' => 'text',
    ),
    'background-color' => 
    array (
      'value' => '#f5f5f5',
      'type' => 'color',
    ),
    'background-hover-color' => 
    array (
      'value' => '#1276e6',
      'type' => 'color',
    ),
    'background-border-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
    'background-border-hover-color' => 
    array (
      'value' => 'rgba(255, 255, 255, 0)',
      'type' => 'color',
    ),
  ),

'title' => 'setting-title',
);