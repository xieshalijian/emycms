<?php return array (
  'custom' =>
      array (
          'title-size' =>
              array (
                  'value' => '22px',
                  'type' => 'text',
              ),
          'title-color' =>
              array (
                  'value' => '#333333',
                  'type' => 'color',
              ),
          'title-hover-color' =>
              array (
                  'value' => '#333333',
                  'type' => 'color',
              ),
          'text-align' =>
              array (
                  'value' => 'text-center',
                  'type' => 'select',
                  'select' => 'text-left/居左,text-center/居中,text-right/居右',
              ),
          'subtitle-size' =>
              array (
                  'value' => '14px',
                  'type' => 'text',
              ),
          'subtitle-color' =>
              array (
                  'value' => '#000000',
                  'type' => 'color',
              ),
          'subtitle-hover-color' =>
              array (
                  'value' => '#000000',
                  'type' => 'color',
              ),
          'p-size' =>
              array (
                  'value' => '16px',
                  'type' => 'text',
              ),
          'p-color' =>
              array (
                  'value' => '#333333',
                  'type' => 'color',
              ),
          'p-hover-color' =>
              array (
                  'value' => '#333333',
                  'type' => 'color',
              ),
          'background-color' =>
              array (
                  'value' => 'rgba(255, 255, 255, 0)',
                  'type' => 'color',
              ),
          'background-hover-color' =>
              array (
                  'value' => 'rgba(255, 255, 255, 0)',
                  'type' => 'color',
              ),
          'background-border-color' =>
              array (
                  'value' => 'rgba(255, 255, 255, 0)',
                  'type' => 'color',
              ),
          'background-border-hover-color' =>
              array (
                  'value' => 'rgba(255, 255, 255, 0)',
                  'type' => 'color',
              ),
      ),

'title' => 'setting-title',
);