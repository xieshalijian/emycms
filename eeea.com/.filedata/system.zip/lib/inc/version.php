<?php

define('_VERSION','7_2_4_201900911_UTF8');
define('_VERNUM','7.2.4.20190911');
define('_VERCODE','7200');
