<?php
if (!defined('ROOT')) exit('Can\'t Access !');

class expansion_admin extends admin
{

    function init(){
        if (!front::get('page'))
            front::$get['page'] = 1;
        $this->_pagesize = config::getadmin('manage_pagesize');
    }

    function index_action()
    {
        if(front::get('leftname') != ''){
            $menu = admin_menu::allmenu();
            $this->view->data = $menu[front::get('leftname')];
            $this->view->leftname = front::get('leftname');
        };

        //本地的
        $data=apps::getInstance()->getrows("",0);
        foreach ($data as $key=>$vaule){
                if(!$vaule['isbuy']){
                    unset($data[$key]);
                }
        }
        //$this->view->appsdate=$this->pagedata($data,front::$get['page'],$this->_pagesize);
        $this->view->appsdate=$data;
        $this->view->pagesize=$this->_pagesize;
        $this->view->page=front::$get['page'];
        $this->view->allsize=count($data);

    }

    function wxxcx_action()
    {

    }



    function buyapps_action()
    {
        //获取已经购买的插件
        $returndata=array();
        $app_login = cookie::get('app_login_cookie');
        $app_login = base64_decode($app_login);
        $app_login = xxtea_decrypt($app_login, config::getadmin('cookie_password'));
        if(!empty($app_login)){
            $applogin=unserialize($app_login);   //反序列化
            $url="https://u.cmseasy.cn/index.php?case=client&act=cmseaylogin&username=".$applogin["username"]."&passwrod=".$applogin['passwrod'];  //服务器获取列表的地址
            $data=service::cmseayurl($url);   //获取服务器的数据
            $data=json_decode($data, true);
            if($data['static']){
                $returndata['static']=1;
                $returndata["message"]=$data['message'];  //登陆成功
                $returndata["userdata"]=$data['userdata'];
                $returndata["modeldata"]=$data['modeldata'];
                $returndata["appsdata"]=$data['appsdata'];
                //修改本地缓存购买状态
                foreach($data['appsdata'] as $key=>$val){
                    if($_SERVER['SERVER_NAME']==$val['buyip']){   //已经购买的 并且域名一直  更新本地缓存
                        apps::getInstance()->rec_update("isbuy=1"," id='".$val['buyid']."'");
                    }
                }
            }
        }
        if($returndata['static']!=1 || $returndata==""){
            $returndata['static']=0;
            $returndata["message"]=lang('login_failure');  //登陆失败
            $returndata["modeldata"]="";
            $returndata["userdata"]="";
            $returndata["appsdata"]="";
        }
        $this->view->returndata=$returndata;

        //获取服务器的插件列表
        $url="https://u.cmseasy.cn/index.php?case=client&act=cmsgetApps";  //服务器获取列表的地址
        $data=service::cmseayurl($url);   //获取服务器的数据
        $data=json_decode($data, true);
        if(front::$get['type']=="free"){    //免费   注意：免费版的过滤掉商业版的插件
            foreach ($data as $key=>$val){
                if($val["price"]>0 || $val['iscorp']){
                    unset($data[$key]);
                }
            }
        }
        else if(front::$get['type']=="corp"){  //商业版
            if(session::get('ver') == 'corp'){
                foreach ($data as $key=>$val){
                    if(!$val["iscorp"]){
                        unset($data[$key]);
                    }else{
                        $data[$key]['price']=0;
                    }
                }
            }/*else{
                exit(lang_admin('unauthorized_access'));  //不是商业版 无权访问
            }*/
        }else if(front::$get['type']=="likemenoy"){  //收费
            foreach ($data as $key=>$val){
                if($val["price"]<=0 || $val["iscorp"]){
                    unset($data[$key]);
                }

            }
        }
        //本地的
        foreach ($data as $key=>$vaule){
            $appsdata=apps::getInstance()->getrow(" id='".$vaule['id']."'");
            if(!is_array($appsdata)){    //不存在的时候插入
                apps::getInstance()->rec_insert($vaule);
            }else{
                if($appsdata['installed']){
                    $data[$key]['installed']=1;
                }
                /*if(front::$get['type']=="mybuyapps"){
                    if(!$appsdata['isbuy']){   //我已经购买的插件
                        unset($data[$key]);
                    }
                }*/
                if($returndata['static']){   //登录之后校验已经购买的购买
                    if($appsdata['isbuy']){    //已经购买的不显示
                        unset($data[$key]);
                    }
                }
            }
        }
        $this->view->appsdate=$this->pagedata($data,front::$get['page'],$this->_pagesize);
        $this->view->pagesize=$this->_pagesize;
        $this->view->page=front::$get['page'];
        $this->view->allsize=count($data);
    }

    function buytemplate_action(){
        //获取已经购买的插件
        $app_login = cookie::get('app_login_cookie');
        $app_login = base64_decode($app_login);
        $app_login = xxtea_decrypt($app_login, config::getadmin('cookie_password'));
        if(!empty($app_login)){
            $applogin=unserialize($app_login);   //反序列化
            $url="https://u.cmseasy.cn/index.php?case=client&act=cmseaylogin&username=".$applogin["username"]."&passwrod=".$applogin['passwrod'];  //服务器获取列表的地址
            $data=service::cmseayurl($url);   //获取服务器的数据
            $data=json_decode($data, true);
            if($data['static']){
                $returndata['static']=1;
                $returndata["message"]=$data['message'];  //登陆成功
                $returndata["userdata"]=$data['userdata'];
                $returndata["modeldata"]=$data['modeldata'];
                $returndata["appsdata"]=$data['appsdata'];
                //修改本地缓存购买状态
                foreach($data['modeldata'] as $key=>$val){
                    buytemplate::getInstance()->rec_update("isbuy=1"," code='".$val['buyid']."'");
                }
            }
        }
        if($returndata['static']!=1 || $returndata==""){
            $returndata['static']=0;
            $returndata["message"]=lang('login_failure');  //登陆失败
            $returndata["modeldata"]="";
            $returndata["userdata"]="";
            $returndata["appsdata"]="";
        }
        $this->view->returndata=$returndata;

        //获取服务器的在线模板列表
        $url="https://u.cmseasy.cn/index.php?case=client&act=cmsgetTemplate";  //服务器获取列表的地址
        $data=service::cmseayurl($url);   //获取服务器的数据
        $data=json_decode($data, true);
        if(front::$get['type']=="free" && !front::post('submit')){    //免费
            foreach ($data as $key=>$val){
                if($val["price"]>0){
                    unset($data[$key]);
                }
            }
        }else if(front::$get['type']=="corp" && !front::post('submit') ){  //商业版
            if(session::get('ver') == 'corp'){
                foreach ($data as $key=>$val){
                    if(!$val["iscorp"]){
                        unset($data[$key]);
                    }else{
                        $data[$key]['price']=0;
                    }
                }
            }/*else{
                exit(lang_admin('unauthorized_access'));  //不是商业版 无权访问
            }*/
        }else if(front::$get['type']=="likemenoy" && !front::post('submit')){  //收费
            foreach ($data as $key=>$val){
                if($val["price"]<=0 || ($val["iscorp"] && session::get('ver') == 'corp') ){
                    unset($data[$key]);
                }
            }
        }
        //本地的
        foreach ($data as $key=>$vaule){
            $appsdata=buytemplate::getInstance()->getrow(" code='".$vaule['code']."'");
            if(!is_array($appsdata)){    //不存在的时候插入
                buytemplate::getInstance()->rec_insert($vaule);
            }else{
                if($appsdata['installed']){
                    $data[$key]['installed']=1;
                }
              if(front::$get['type']=="mybuyapps"){
                    if(!$appsdata['isbuy']){
                        unset($data[$key]);
                    }
                }
            }

            //搜索条件
            if(front::post('submit') && front::post('search_coded')){
                if(strpos($vaule['code'],front::post('search_coded')) === false){
                    unset($data[$key]);
                }
            }
        }
        $this->view->appsdate=$this->pagedata($data,front::$get['page'],$this->_pagesize);
        $this->view->pagesize=$this->_pagesize;
        $this->view->page=front::$get['page'];
        $this->view->allsize=count($data);

    }

    //分页
    function pagedata($data,$page,$size){
            $index=1;
            $returndata=array();
            if($page==1){
                foreach ($data as $key=>$val){
                    if($index<=$size){
                        $returndata[$key]=$val;
                    }
                    $index++;
                }
            }else{
                foreach ($data as $key=>$val){
                    if($index>($page-1)*$size && $index<=$page*$size){
                        $returndata[$key]=$val;
                    }
                    $index++;
                }
            }
            return $returndata;
    }

    //刷新插件列表  重新从服务端获取
   function getcmeasyAppps_action(){
           $url="https://u.cmseasy.cn/index.php?case=client&act=cmsgetApps";  //服务器获取列表的地址
           $data=service::cmseayurl($url);   //获取服务器的数据
           $data=json_decode($data, true);
           if(count($data)>0){
               foreach ($data as $key=>$vaule){
                   $appsdata=apps::getInstance()->getrow(" id='".$vaule['id']."'");
                   if(!is_array($appsdata)){    //不存在的时候插入
                       apps::getInstance()->rec_insert($vaule);
                   }
               }
           }
           front::redirect(url::modify('act/index', true));
   }

function end()
    {
        $this->render();
    }
}