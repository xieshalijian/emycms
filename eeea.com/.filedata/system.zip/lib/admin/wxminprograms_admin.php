<?php

if (!defined('ROOT')) exit('Can\'t Access !');
class wxminprograms_admin extends admin {

    function init()
    {}

    function query_action()
    {
        echo '666';
        exit;
    }

    function end()
    {
    }
}