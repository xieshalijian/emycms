<?php
if (!defined('ROOT')) exit('Can\'t Access !');

class service_admin extends admin
{
    function init()
    {
    }

    function index_action()
    {

    }






    function end()
    {
        $this->render();
    }
}