<?php

if (!defined('ROOT')) exit('Can\'t Access !');

class hprose_act extends act
{

    public function license_action(){
        include_once(ROOT.'/lib/plugins/hprose/Hprose.php');
        $hprose = new \Hprose\Http\Server();
        $hprose->debug = true;
        $hprose->crossDomain = true;
        $license = license::getInstance();
        $hprose->addMethods(array(
            'getCDKey',
            'chkMoney',
            'BuyLicense'
        ),$license);
        $hprose->handle();
        /*$res = $license->getCDKey(array('domain'=>'www.visual.com','addtime'=>date('Y-m-d H:i:s')));
        header("Cache-Control: max-age=0");
        header("Content-Description: File Transfer");
        Header("Content-type: application/zip");
        header("Content-Transfer-Encoding: binary");
        Header("Accept-Ranges: bytes");
        Header("Accept-Length: ".filesize($res));
        Header("Content-Disposition: attachment; filename=".basename($res));
        readfile($res);*/
    }

    public function handle_action(){
        include_once(ROOT.'/lib/plugins/hprose/Hprose.php');
        $hprose = new \Hprose\Http\Server();
        $hprose->debug = true;
        $hprose->crossDomain = true;
        $vhost = vhost::getInstance();
        $hprose->addMethods(array(
            'Trial',
            'InsTemp',
            'chkDomain',
            'getConnSetting',
            'OneKey',
            'chkMoney',
            'setFtpPass',
            'setSqlPass',
            'deleteSite',
            'getDomain',
            'delDomain',
            'addDomain',
            'getYear',
            'Renew',
            'getPHPVersionList',
            'getSitePHPVersion',
            'setPHPVersion',
            'getSiteLogs',
            'setIndex',
            'get301Status',
            'set301Status',
            'getSecurity',
            'setSecurity',
            'setSsl',
            'getDir',
            'getRewrite',
            'setRewrite',
            'zip',
            'unZip'
        ),$vhost);
        //$hprose->addMethod('Trial',$vhost);
        $hprose->handle();
    }
}